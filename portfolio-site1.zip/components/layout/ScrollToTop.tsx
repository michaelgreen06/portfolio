"use client"

import { useScrollTop } from "@/hooks/use-scroll-top"

export default function ScrollToTop() {
  useScrollTop()
  return null
}

